import expression
dict1 =	{
  "A": "Hello",
  "B": "World",
  "C": "Buddy"
}
dict2 = { "and":logic.and,"or":or}
var1 = {"A","B","C"}
print(dict["A"])
var2 = {"and","or"}

text=input("Enter a string : ")
print(text.split())
words = text.split()
l = len(words)

for key in var2:
    text = text.replace(key, dict2[key])
    print(text)
for key in var1:
    text = text.replace(key, dict1[key])

print (text)
print(eval(text))